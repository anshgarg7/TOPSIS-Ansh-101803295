import topsis from .__main__
name="TOPSIS_Ansh_101803295/TOPSIS_Ansh_101803295"
__version__ = "1.0.0"
